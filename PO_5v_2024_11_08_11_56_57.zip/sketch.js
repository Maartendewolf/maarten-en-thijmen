
var naam1 = "jaap";
var naam2 = "maarten";
var naam3 = "maartenw"; // elke bom een var, dus elke een naam
var naam4 = "axel";
var naam5 = "thijmen";

var Bom = new Array("jaap", "maarten", "maartenw", "axel", "thijmen"); // totale array
let bommen = [];

let Levens = 20;

class Raster {
  constructor(r, k) {
    this.aantalRijen = r;
    this.aantalKolommen = k;
    this.celGrootte = null;
  }
 
  berekenCelGrootte() {
    this.celGrootte = canvas.width / this.aantalKolommen;
  }
  
  
  teken() {
    push();
    noFill();
    stroke('grey');
    for (var rij = 0; rij < this.aantalRijen; rij++) {
      for (var kolom = 0; kolom < this.aantalKolommen; kolom++) {
        rect(kolom * this.celGrootte, rij * this.celGrootte, this.celGrootte, this.celGrootte);
      }
    }
    pop();
  }
}


class Jos {
  constructor() {
    this.x = 400;
    this.y = 300;
    this.animatie = [];
    this.frameNummer = 3;
    this.stapGrootte = null;
    this.gehaald = false;
  }
 
  beweeg() {
    if (keyIsDown(65)) { // 65 is de keycode voor knop A
      this.x -= this.stapGrootte;
      this.frameNummer = 2;
    }
    if (keyIsDown(68)) { // 68 is de keycode voor knop D
      this.x += this.stapGrootte;
      this.frameNummer = 1;
    }
    if (keyIsDown(87)) { // 87 is de keycode voor knop W
      this.y -= this.stapGrootte;
      this.frameNummer = 4;
    }
    if (keyIsDown(83)) { // 83 is de keycode voor knop S
      this.y += this.stapGrootte;
      this.frameNummer = 5;
    }
   
    this.x = constrain(this.x, 0, canvas.width); // dit zorgt er voor dat jos niet uit het beeld kan
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
   
    if (this.x == canvas.width) {
      this.gehaald = true;
    }
  }
 
  wordtGeraakt(object) {
    return (
      this.x < object.x + raster.celGrootte &&
      this.x + raster.celGrootte > object.x &&
      this.y < object.y + raster.celGrootte &&
      this.y + raster.celGrootte > object.y
    );
  } // deze code checkt of jos de bommen raakt
  
  
  
 
  toon() {
    image(this.animatie[this.frameNummer], this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class Vijand {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.sprite = null;
    this.stapGrootte = null;
  }

  beweeg() {
    this.x += floor(random(-1, 2)) * this.stapGrootte;
    this.y += floor(random(-1, 2)) * this.stapGrootte;

    this.x = constrain(this.x, 0, canvas.width - raster.celGrootte);
    this.y = constrain(this.y, 0, canvas.height - raster.celGrootte);
  }
 
  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}

class Leven1 {
  constructor(x, y) {
    this.x = random(0, canvas.width);
    this.y = random(0, canvas.height);
    this.snelheidX = 8;
    this.snelheidY = 6;
    this.grootte = raster.celGrootte * 0.5;
  }
 
  beweeg() {
    this.x += this.snelheidX;
    this.y += this.snelheidY;
   
    if (this.x < 0 || this.x > canvas.width - this.grootte) {
      this.snelheidX *= -1;
    }
    if (this.y < 0 || this.y > canvas.height - this.grootte) {
      this.snelheidY *= -1;
    }
    this.x = constrain(this.x, 0, canvas.width - this.grootte);
    this.y = constrain(this.y, 0, canvas.height - this.grootte);
  }
 
  toon() {
    image(Groenappel.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}// dit is de class voor de groene appel, met daarbij de eigenschappen




class Leven2 {
  constructor(x, y){
    this.x = 50;
    this.y = 450;
    this.grootte = raster.celGrootte * 0.5;
     this.actief = true;
  }
  
  toon() {
    if (this.actief){ 
    image(Roodappel.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
  }
}// dit is de class voor de groene appel, met daarbij de eigenschappen





class Bommen {
  constructor(x, y, snelheid) {
    this.x = x;
    this.y = y;
    this.snelheid = snelheid;
    this.sprite = loadImage("images/sprites/bom_100px.png");  
    this.direction = 1;
  } // in deze class worden de eigenschappen van de bommen bepaald en dus ook de image
 
  beweeg() {
    this.y += this.snelheid * this.direction;

    if (this.y <= 0 || this.y >= canvas.height - raster.celGrootte) {
      this.direction *= -1;
    }
  }
 
  toon() {
    image(this.sprite, this.x, this.y, raster.celGrootte, raster.celGrootte);
  }
}
function preload() {
  brug = loadImage("images/backgrounds/dame_op_brug_1800.jpg");
  Goud = loadImage("images/backgrounds/blurred_gold_L.jpg");
} // dit zijn images die stil staan in het spel, dus denk aan de achtergronden.

function setup() {
  canvas = createCanvas(900, 600);
  canvas.parent();
  frameRate(10);
  textFont("Verdana");
  textSize(90);
 
  raster = new Raster(12, 18);
  raster.berekenCelGrootte();
 // hier bepalen we de grootte van het raster
  
  
  eve = new Jos();
  eve.stapGrootte = 1 * raster.celGrootte;
  for (var b = 0; b < 6; b++) {
    let frameEve = loadImage("images/sprites/Eve100px/Eve_" + b + ".png");
    eve.animatie.push(frameEve);
  }//dit is jos
 
  alice = new Vijand(700, 200);
  alice.stapGrootte = 1 * eve.stapGrootte;
  alice.sprite = loadImage("images/sprites/Alice100px/Alice.png");

  bob = new Vijand(600, 400);
  bob.stapGrootte = 1 * eve.stapGrootte;
  bob.sprite = loadImage("images/sprites/Bob100px/Bob.png");  
 // deze 2 zijn de vijanden van jos
  
  Groenappel = new Leven1();
  Groenappel.sprite = loadImage("images/sprites/appel_1.png");
 //dit is de groene appel
  
  Roodappel = new Leven2();
  Roodappel.sprite = loadImage("images/sprites/appel_2.png");

  
  for (let i = 0; i < 5; i++) {
    let x = random(450, canvas.width - raster.celGrootte);
    let y = random(0, canvas.height - raster.celGrootte);
    let snelheid = random(5,15);
    let bom = new Bommen(x, y, snelheid);
    bommen.push(bom);
  }//dit zorgt voor de random plekken van de bom
}

function draw() {

  if (
    (mouseX >= 50 && mouseX <= 100 && mouseY >= 0 && mouseY <= canvas.height) ||  // Linker verticale balk
    (mouseX >= 0 && mouseX <= canvas.width && mouseY >= 475 && mouseY <= 525)     // Onderste horizontale balk
  ) {
    background(Goud) 
  } else {
    background(brug);  
  } // bij de if kan je zien dat als de muis over de balken heen gaan dat de achtergrond veranderd, anders blijft die hetzelfde
     noStroke();
fill('orange')
rect(50,0,50,1000)

  noStroke();
 fill('orange')
 rect(0,450,1000,50)
  // dit zijn de oranje balken
  raster.teken();

  
  eve.beweeg();
  alice.beweeg();
  bob.beweeg();
  eve.toon();
  alice.toon();
  bob.toon();
  Groenappel.toon();
  Groenappel.beweeg();
  Roodappel.toon();

  for (let bom of bommen) {
    bom.beweeg();
    bom.toon();
  }
 // dit zorgt ervoor dat de bewegingen en plaatjes ook daadwerkelijk in het canvas komen

  


  if (eve.wordtGeraakt(Groenappel)) {
    Levens++;  // als jos de groene appel raakt, krijgt hij een extra leven
  
    Groenappel.x = random(0, canvas.width - raster.celGrootte);
    Groenappel.y = random(0, canvas.height - raster.celGrootte);
  }// dit zorgt ervoor nadat de groene appel is geraakt, je een nieuw leven krijgt en dat die naar een nieuwe random plek gaat, onze extra feature!!!!!!!!!!!!!!!!
  
  if (Roodappel.actief && eve.wordtGeraakt(Roodappel)){
    Levens++;
      Roodappel.actief = false;
  }// dit zorgt ervoor dat als de rode appel is geraakt, je een leven krijgt en dat hij verdwijnt
  
  
  
  fill("black");
  textSize(24);
  text("levens = " + Levens, 20, 30);
  // zorgt voor de levensteller linksboven
 
  if (eve.wordtGeraakt(alice) || eve.wordtGeraakt(bob) || bommen.some(bom => eve.wordtGeraakt(bom))) {
    Levens--;
  }// als jos een bom of een vijand raakt, gaat er een leven vanaf

  if (Levens <= 0) {
    background('red');
    fill('white');
    textSize(40);
    text("Je hebt helaas verloren", 325, 300);
    noLoop();
  }// eindboodschap als je verliest

  if (eve.gehaald) {
    background('green');
    fill('white');
    textSize(40);
    text("Je hebt gewonnen!", 325, 300);
  } // eindboodschap als je wint
}